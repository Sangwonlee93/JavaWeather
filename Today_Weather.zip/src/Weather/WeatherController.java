package Weather;

import java.util.ArrayList;

public class WeatherController {
	WeatherModel wm = new WeatherModel();
	SerialModel sm = new SerialModel();
	NewsModel nm = new NewsModel();
	WeatherManufacture wman;
	public ArrayList<String> retrunCurData(){
		wman = new WeatherManufacture(wm.reciveData());
		return wman.returnData();
	}
	public ArrayList<String> retrunSerialData(){
		return sm.reciveData();
	}
	public ArrayList<NewsInfo> retrunNewsData(){
		return nm.reciveData();
	}
}
