package Weather;

import java.util.ArrayList;

public class WeatherManufacture {
	String Sky=""; // �ϴû���
	String PTY=""; // ��������
	String Temper=""; // ���
	String Hum=""; // ����
	String Rain=""; // ����Ȯ��
	String RPrecipitation=""; //  ������
	String SPrecipitation="";//������
	String Windspeed=""; // ǳ��
	ArrayList<CurWeatherInfo> Data;
	String Feeltemper=""; // ü���µ�
	String weather="";
	String dn="";
	public WeatherManufacture(ArrayList<CurWeatherInfo> Data) {
		this.Data=Data;
	}
	public ArrayList<String> returnData() {
		ArrayList<String> result = new ArrayList<String>();
		boolean IsExist=false;
		//���� ����
		for(int i=0; i<Data.size(); i++) {
			if(Data.get(i).getcate().equals("SKY")) {
				Sky = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("PTY")) {
				PTY = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("REH")) {
				Hum = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("POP")) {
				Rain = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("T3H")) {
				Temper = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("WSD")) {
				Windspeed = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("R06")) {
				RPrecipitation = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("S06")) {
				SPrecipitation = Data.get(i).getvalue();
			}else if(Data.get(i).getcate().equals("time")) {
				dn = Data.get(i).getvalue();
			}
			
		}
		if(PTY.equals("0")) {
			if(Sky.equals("1")) {
				weather="����";
			}else if(Sky.equals("2")) {
				weather="��������";
			}else if(Sky.equals("3")) {
				weather="��������";
			}else if(Sky.equals("4")) {
				weather="�帲";
			}else {
				weather="-";
			}
		}else if(PTY.equals("1")) {
			weather = "��";
		}else if(PTY.equals("2")) {
			weather = "��������";
		}else if(PTY.equals("3")) {
			weather = "��";
		}
		double temp = 13.12+0.6215*Double.parseDouble(Temper)-11.37*Math.pow(Double.parseDouble(Windspeed),0.16)+0.3965*Math.pow(Double.parseDouble(Windspeed),0.16)*Double.parseDouble(Temper);
		Feeltemper=Double.toString(Math.round(temp*10)/10);
		
		result.add(weather);
		result.add(Temper);
		result.add(Hum);
		result.add(Windspeed);
		result.add(Feeltemper);
		result.add(Rain);
		if(weather.equals("��")) {
			result.add(SPrecipitation);
		}else {
			result.add(RPrecipitation);
		}
		result.add(dn);
		return result;
	}
}
