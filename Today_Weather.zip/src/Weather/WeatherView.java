package Weather;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.CardLayout;
import java.awt.GridBagLayout;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JRadioButton;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;

public class WeatherView extends JFrame implements ActionListener{

	private WeatherController wc = new WeatherController();
	private ArrayList<String> data;
	private int status;
	private JPanel panel1 = new JPanel();
	private JPanel panel2 = new JPanel();
	private JPanel panel3 = new JPanel();
	private JPanel panel4 = new JPanel();
	private JPanel panel5 = new JPanel();
	private JPanel panel6 = new JPanel();
	private JButton btn1 = new JButton("���׿���");
	private JButton btn2 = new JButton("�ǳ�����");
	private JButton btn3 = new JButton("���ΰ�ħ");
	private JButton btn4 = new JButton("��������");
	private JLabel label1 = new JLabel("���� ����");
	private JLabel label2 = new JLabel("");
	private JLabel label3 = new JLabel("");
	private JLabel label4 = new JLabel("");
	private JLabel label5 = new JLabel("");
	private JLabel label6 = new JLabel("");
	private JLabel label7 = new JLabel("");
	private JLabel label8 = new JLabel("");
	private JLabel [] news = new JLabel[10];
	private JButton [] link = new JButton[10];
	
	public WeatherView() {
		status = 0;
		StratView();
	}
	public void StratView() {
		data = wc.retrunCurData();
		setResizable(false);
		Container con = this.getContentPane();
		con.setBackground(Color.WHITE);
		con.setLayout(new BorderLayout());
		label1.setHorizontalAlignment(SwingConstants.CENTER);
		label1.setFont(new Font("HY����M",Font.PLAIN,50));
		con.add(label1, "North");
		btn1.setBackground(Color.WHITE);
		btn1.setFont(new Font("HY����M", Font.PLAIN, 20));
		btn2.setBackground(Color.WHITE);
		btn2.setFont(new Font("HY����M", Font.PLAIN, 20));
		btn3.setBackground(Color.WHITE);
		btn3.setFont(new Font("HY����M", Font.PLAIN, 20));
		btn4.setBackground(Color.WHITE);
		btn4.setFont(new Font("HY����M", Font.PLAIN, 20));
		panel5.setLayout(new FlowLayout());
		panel5.add(btn1);
		panel5.add(btn2);
		panel5.add(btn4);
		panel5.add(btn3);
		con.add(panel5, "South");
		panel1.setLayout(new GridLayout(1,3));
		panel2.setLayout(new GridLayout(2,1));
		panel3.setLayout(new GridLayout(2,1));
		panel4.setLayout(new GridLayout(3,1));
		if(data.get(0).equals("����")) {
			if(data.get(data.size()-1).equals("n")) {
				label2.setIcon(new ImageIcon("./src/image/Moon.PNG"));
			}else {
				label2.setIcon(new ImageIcon("./src/image/Sunny.PNG"));
			}
		}else if(data.get(0).equals("��������")) {
			label2.setIcon(new ImageIcon("./src/image/CloudyLow.PNG"));
		}else if(data.get(0).equals("��������")) {
			label2.setIcon(new ImageIcon("./src/image/CloudyHigh.PNG"));
		}else if(data.get(0).equals("�帲")) {
			label2.setIcon(new ImageIcon("./src/image/Cloudy.PNG"));
		}else if(data.get(0).equals("��")) {
			label2.setIcon(new ImageIcon("./src/image/Rainny.PNG"));
		}else if(data.get(0).equals("��������")) {
			label2.setIcon(new ImageIcon("./src/image/Rainny.PNG"));
		}else if(data.get(0).equals("��")) {
			label2.setIcon(new ImageIcon("./src/image/Snowy.PNG"));
		}
		label2.setHorizontalAlignment(SwingConstants.CENTER);
		panel2.add(label2);
		label3.setFont(new Font("HY����M", Font.PLAIN, 32));
		label3.setHorizontalAlignment(SwingConstants.CENTER);
		label3.setText(data.get(1)+"��");
		label4.setIcon(new ImageIcon("./src/image/hum.PNG"));
		label4.setHorizontalAlignment(SwingConstants.LEFT);
		label4.setFont(new Font("HY����M", Font.PLAIN, 20));
		label4.setText(data.get(2)+"%");
		
		label5.setIcon(new ImageIcon("./src/image/wind.PNG"));
		label5.setHorizontalAlignment(SwingConstants.LEFT);
		label5.setFont(new Font("HY����M", Font.PLAIN, 20));
		label5.setText(data.get(3)+"m/s");
		
		label6.setText("ü���µ� : "+data.get(4)+"��");
		label6.setHorizontalAlignment(SwingConstants.CENTER);
		label6.setFont(new Font("HY����M", Font.PLAIN, 20));
		
		label7.setText("����Ȯ�� : "+data.get(5)+"%");
		label7.setHorizontalAlignment(SwingConstants.CENTER);
		label7.setFont(new Font("HY����M", Font.PLAIN, 20));
		
		if(data.get(0).equals("��")) {
			label8.setText("������ : "+data.get(6)+"mm");
		}else if(data.get(0).equals("��������")) {
			label8.setText("������ : "+data.get(6)+"mm");;
		}else if(data.get(0).equals("��")) {
			label8.setText("������ : "+data.get(6)+"cm");
		}else {
			label8.setText("-");
		}
		label8.setHorizontalAlignment(SwingConstants.CENTER);
		label8.setFont(new Font("HY����M", Font.PLAIN, 20));
		panel6.setLayout(new GridLayout(20,1));
		panel6.setBackground(Color.WHITE);
		for(int i=0; i<10; i++) {
			news[i] = new JLabel("");
			link[i] = new JButton("");
			news[i].setFont(new Font("HY����M", Font.PLAIN, 10));
			link[i].setFont(new Font("HY����M", Font.PLAIN, 10));
			link[i].setBackground(Color.WHITE);
			link[i].setHorizontalAlignment(SwingConstants.LEFT);
			link[i].setBorder(null);
			link[i].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					JButton temp = (JButton)e.getSource(); 
					try {
						Desktop.getDesktop().browse(new java.net.URI(temp.getText()));
					} catch (IOException | URISyntaxException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			panel6.add(news[i]);
			panel6.add(link[i]);
		}
		panel4.add(label6);
		panel4.add(label7);
		panel4.add(label8);
		panel3.add(label4);
		panel3.add(label5);
		panel2.add(label3);
		panel1.add(panel2);
		panel1.add(panel3);
		panel1.add(panel4);
		con.add(panel1,"Center");
		panel1.setBackground(Color.WHITE);
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(Color.WHITE);
		panel4.setBackground(Color.WHITE);
		panel5.setBackground(Color.WHITE);
		btn1.addActionListener(this);
		btn2.addActionListener(this);
		btn3.addActionListener(this);
		btn4.addActionListener(this);
		this.setTitle("����");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(700, 500);
		this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object obj = e.getSource();
		if(obj == btn1) {
			status=0;
			setApiWeather();
			this.getContentPane().remove(panel6);
			this.getContentPane().add(panel1,"Center");
			this.revalidate();
			repaint();
		}else if(obj == btn2) {
			status=1;
			setSerialWeather();
			this.getContentPane().remove(panel6);
			this.getContentPane().add(panel1,"Center");
			this.revalidate();
			repaint();
		}else if(obj == btn3) {
			if(status == 0) {
				status=0;
				setApiWeather();
				this.revalidate();
				repaint();
			}else if(status == 1){
				status=1;
				setSerialWeather();
				this.revalidate();
				repaint();
			}else if(status == 2){
				status=2;
				setNews();
				this.revalidate();
				repaint();
			}
		}else if(obj == btn4) {
			status=2;
			setNews();
			this.getContentPane().remove(panel1);
			this.getContentPane().add(panel6,"Center");
			this.revalidate();
			repaint();
		}
	}
	void setApiWeather() {
		System.out.println("����");
		label1.setText("���� ����");
		data = wc.retrunCurData();
		if(data.get(0).equals("����")) {
			if(data.get(data.size()-1).equals("n")) {
				label2.setIcon(new ImageIcon("./src/image/Moon.PNG"));
			}else {
				label2.setIcon(new ImageIcon("./src/image/Sunny.PNG"));
			}
		}else if(data.get(0).equals("��������")) {
			label2.setIcon(new ImageIcon("./src/image/CloudyLow.PNG"));
		}else if(data.get(0).equals("��������")) {
			label2.setIcon(new ImageIcon("./src/image/CloudyHigh.PNG"));
		}else if(data.get(0).equals("�帲")) {
			label2.setIcon(new ImageIcon("./src/image/Cloudy.PNG"));
		}else if(data.get(0).equals("��")) {
			label2.setIcon(new ImageIcon("./src/image/Rainny.PNG"));
		}else if(data.get(0).equals("��������")) {
			label2.setIcon(new ImageIcon("./src/image/Rainny.PNG"));
		}else if(data.get(0).equals("��")) {
			label2.setIcon(new ImageIcon("./src/image/Snowy.PNG"));
		}
		label3.setText(data.get(1)+"��");
		label4.setText(data.get(2)+"%");
		label5.setText(data.get(3)+"m/s");
		label6.setText("ü���µ� : "+data.get(4)+"��");
		label7.setText("����Ȯ�� : "+data.get(5)+"%");
		if(data.get(0).equals("��")) {
			label8.setText("������ : "+data.get(6)+"mm");
		}else if(data.get(0).equals("��������")) {
			label8.setText("������ : "+data.get(6)+"mm");;
		}else if(data.get(0).equals("��")) {
			label8.setText("������ : "+data.get(6)+"cm");
		}else {
			label8.setText("-");
		}
	}
	void setSerialWeather() {
		System.out.println("�ǳ�");
		label1.setText("�ǳ� ����");
		data = wc.retrunSerialData();
		label2.setIcon(new ImageIcon("./src/image/home.PNG"));
		label3.setText(data.get(data.size()-2)+"��");
		label4.setText(data.get(data.size()-1)+"%");
		label5.setText("0m/s");
		label6.setText(data.get(data.size()-2)+"��");
		label7.setText("�ǳ�");
		label8.setText("-");
	}
	void setNews() {
		System.out.println("����");
		label1.setText("���� ����");
		ArrayList<NewsInfo> temp = wc.retrunNewsData();
		for(int i=0; i<10; i++) {
			news[i].setText(temp.get(i).gettitle());
			link[i].setText(temp.get(i).getlink());
		}
	}
}
