package Weather;

public class CurWeatherInfo {
	String cate;
	String value;
	String time;
	public CurWeatherInfo(String cate, String value,String time) {
		this.cate = cate;
		this.value = value;
		this.time = time;
	}
	public String getcate() {
		return this.cate;
	}
	public String getvalue() {
		return this.value;
	}
	public String gettime() {
		return this.time;
	}
}
