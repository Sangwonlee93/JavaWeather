package Weather;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class NewsModel {
	ArrayList<NewsInfo> result = new ArrayList<NewsInfo>();
	String word = "����";
	String requestUrl = "https://openapi.naver.com/v1/search/news.xml?query=";
	String naverId = "oCWkSXHM3WmOS4XUmfoU";
	String naverSecret = "cyalIoQ8LT";
	public NewsModel() {
		
	}
	public ArrayList<NewsInfo> reciveData() {
		try{
			 String title = "";
			 String link = "";
			 String query = URLEncoder.encode(word,"UTF-8");
			 requestUrl = "https://openapi.naver.com/v1/search/news.xml?query="+query+"&sort=sim";
	         URL url = new URL(requestUrl);
	         URLConnection conn = url.openConnection();
	         HttpURLConnection httpConnection = (HttpURLConnection)conn;
	         httpConnection.setRequestMethod("GET");
	         httpConnection.setRequestProperty("X-Naver-Client-Id", naverId);
	         httpConnection.setRequestProperty("X-Naver-Client-Secret", naverSecret);
	         InputStreamReader in = new InputStreamReader(httpConnection.getInputStream(),"utf-8");
	         int c;
	         StringBuffer buf= new StringBuffer();
	         
	         while((c=in.read())!=-1) {
	        	 buf.append((char)c);
	         }
	         in.close();
	         DocumentBuilderFactory dbFactory=DocumentBuilderFactory.newInstance();
	         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	         Document doc =dBuilder.parse(new InputSource(new StringReader(buf.toString())));
	         NodeList nlist= doc.getElementsByTagName("item");
	         for(int i=0; i<nlist.getLength(); i++){
	            for(Node n = nlist.item(i).getFirstChild(); n!=null; n=n.getNextSibling()){
	               if(n.getNodeName().equals("title")){
	                 title= n.getTextContent().trim();
	               }else if(n.getNodeName().equals("link")) {
	            	   link = n.getTextContent().trim();
	               }
	            }
	            title=title.replaceAll("<b>","");
	            title=title.replaceAll("</b>", "");
	            title=title.replaceAll("&quot", "");
		        NewsInfo temp = new NewsInfo(title,link);
		        result.add(temp);
	         }
	      }catch(Exception e){
	         
	      }
		return result;
	}
}
