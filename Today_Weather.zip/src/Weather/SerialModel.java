package Weather;

import java.util.ArrayList;
import java.util.StringTokenizer;

import jssc.SerialPort;
import jssc.SerialPortException;

public class SerialModel
{
	public SerialModel() {
		
	}
	public ArrayList<String> reciveData() {
		ArrayList<String> data = new ArrayList<String>();
	    SerialPort serialPort = new SerialPort("COM3");
	    try {
	        serialPort.openPort();//Open serial port
	        serialPort.setParams(9600, 8, 1, 0);//Set params.
	        String buffer = serialPort.readString(18);//Read 10 bytes from serial port
	        serialPort.closePort();//Close serial port
	        System.out.println(buffer);
	        for(int i=buffer.length()-1;i>=0;i--) {
	        	if(buffer.charAt(i)=='#') {
	        		buffer=buffer.substring(0, i);
	        		break;
	        	}
	        }
	        StringTokenizer st = new StringTokenizer(buffer,"#");
	        while(st.hasMoreTokens()) {
	        	String temp = st.nextToken();
	        	StringTokenizer st1 = new StringTokenizer(temp,"%");
	        	while(st1.hasMoreTokens()) {
	        		data.add(st1.nextToken());
	        		data.add(st1.nextToken());
	        	}
	        }
	        
	        for(int i=0; i<data.size(); i++) {
	        	System.out.println(data.get(i));
	        }
	    }
	    catch (SerialPortException ex) {
	        System.out.println(ex);
	    }
		return data;
	}
}