package Weather;

import java.io.*; 
import java.net.*;
import java.util.*;

import javax.xml.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;

import java.util.Calendar;
import java.text.SimpleDateFormat;

public class WeatherModel {
   String authKey = "0t%2BbLLqozlCvYUzVnWz1fKSXtlENpTl%2BXs8AI6lIBBlDaN6J12D%2FjOIzseBzGJ%2FVIDWRg1%2BXnyN6E0WVku9p1A%3D%3D";
   String requestUrl=null;
   
   ArrayList<CurWeatherInfo> CurList;
   SimpleDateFormat sdf;
   SimpleDateFormat sdf2;
   String strToday;
   int curTime;
   String basetime;
   String temptime;
   public WeatherModel(){
	   sdf = new SimpleDateFormat("yyyyMMdd");
	   Calendar c = Calendar.getInstance();
	   strToday=sdf.format(c.getTime());
	   sdf2 = new SimpleDateFormat("HHmm");
	   curTime = Integer.parseInt(sdf2.format(c.getTime()));
	   if(curTime>=0 && curTime<300) {
		   basetime = "2000";
		   temptime = "0000";
		   c.add(Calendar.DATE, -1);
		   strToday=sdf.format(c.getTime());
	   }else if(curTime>=300 && curTime<600) {
		   basetime = "2300";
		   temptime = "0300";
		   c.add(Calendar.DATE, -1);
		   strToday=sdf.format(c.getTime());
	   }else if(curTime>=600 && curTime<900) {
		   basetime = "0200";
		   temptime = "0600";
	   }else if(curTime>=900 && curTime<1200) {
		   basetime = "0500";
		   temptime = "0900";
	   }else if(curTime>=1200 && curTime<1500) {
		   basetime = "0800";
		   temptime = "1200";
	   }else if(curTime>=1500 && curTime<1800) {
		   basetime = "1100";
		   temptime = "1500";
	   }else if(curTime>=1800 && curTime<2100) {
		   basetime = "1400";
		   temptime = "1800";
	   }else if(curTime>=2100 && curTime<2400) {
		   basetime = "1700";
		   temptime = "2100";
	   }
   }
   public ArrayList<CurWeatherInfo> reciveData(){
      String cate="";
      String value="";
      String time ="";
      CurList = new ArrayList<CurWeatherInfo>();
      try{
         requestUrl = "http://newsky2.kma.go.kr/service/SecndSrtpdFrcstInfoService2/ForecastSpaceData?serviceKey="+authKey+"&base_date="+strToday+"&base_time="+basetime+"&nx=60&ny=120&numOfRows=14&_type=xml";
         System.out.println(basetime);
         URL url = new URL(requestUrl);
         InputStream is = url.openStream();
         DocumentBuilderFactory dbFactory=DocumentBuilderFactory.newInstance();
         DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
         Document doc =dBuilder.parse(is);
         
         NodeList nlist= doc.getElementsByTagName("item");
         
         for(int i=0; i<nlist.getLength(); i++){
            for(Node n = nlist.item(i).getFirstChild(); n!=null; n=n.getNextSibling()){
               if(n.getNodeName().equals("category")){
                  cate=n.getTextContent().trim();
               }else if(n.getNodeName().equals("fcstTime")) {
            	   time=n.getTextContent().trim();
               }else if(n.getNodeName().equals("fcstValue")){
            	   value=n.getTextContent().trim();
               }
            }
            CurWeatherInfo temp = new CurWeatherInfo(cate,value,time);
            CurList.add(temp);
            
         }
      }catch(Exception e){
         
      }
      for(int i=0; i<CurList.size(); i++) {
    	  if(!CurList.get(i).gettime().equals(temptime)) {
    		  CurList.remove(i);
    		  i--;
    	  }
      }
      String dum="d";
      if(curTime>=1800 && curTime<=2400 || curTime>=0 && curTime<600) {
		   dum = "n";
      }
      CurWeatherInfo time2 = new CurWeatherInfo("time",dum," ");
      CurList.add(time2);
      return CurList;
   }
   
}