package Weather;

public class NewsInfo {
	String title;
	String link;
	public NewsInfo(String title,String link) {
		this.title = title;
		this.link = link;
	}
	public String gettitle() {
		return this.title;
	}
	public String getlink() {
		return this.link;
	}
}
